from django.apps import AppConfig


class MapAppConfig(AppConfig):
    name = 'map_app'
